import { createApp } from 'vue'
import App from './App.vue'

// import FomanticUI from 'vue-fomantic-ui'
// import 'fomantic-ui-css/semantic.min.css'

import './assets/main.css'

// const app = createApp(App)
// app.use(FomanticUI)

createApp(App).mount('#app')
